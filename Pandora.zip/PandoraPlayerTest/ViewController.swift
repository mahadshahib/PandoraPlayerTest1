//
//  ViewController.swift
//  PandoraPlayerTest
//
//  Created by Mamad Shahib on 6/10/1398 AP.
//  Copyright © 1398 AP Mamad Shahib. All rights reserved.
//

import UIKit
import SPStorkController
import AVKit
import AVFoundation
import AudioPlayer

class ViewController: UIViewController {

    let filePath1 = Bundle.main.path(forResource: "1", ofType: "mp3")
    let filePath2 = Bundle.main.path(forResource: "2", ofType: "mp3")
     let audio = try! AudioPlayer(contentsOf: URL(fileURLWithPath: Bundle.main.path(forResource: "2", ofType: "mp3")!))
 
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        audio.play()
    }

    @IBAction func play(_ sender: Any) {
     audio.fadeOut()
        
        
    }
    


    
}

