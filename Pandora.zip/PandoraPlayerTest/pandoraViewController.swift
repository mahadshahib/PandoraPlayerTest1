//
//  pandoraViewController.swift
//  
//
//  Created by Mamad Shahib on 6/10/1398 AP.
//

import UIKit
import AudioPlayer
import AudioPlayerManager
import AVKit
import AVFoundation
import MediaPlayer

class pandoraViewController: UIViewController {

    let filePath1 = Bundle.main.path(forResource: "1", ofType: "mp3")
    let filePath2 = Bundle.main.path(forResource: "2", ofType: "mp3")
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
  
    
        // Do any additional setup after loading the view.
    }

    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
