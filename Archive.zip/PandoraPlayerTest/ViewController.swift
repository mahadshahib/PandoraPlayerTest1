//
//  ViewController.swift
//  PandoraPlayerTest
//
//  Created by Mamad Shahib on 6/10/1398 AP.
//  Copyright © 1398 AP Mamad Shahib. All rights reserved.
//

import UIKit
import SPStorkController
import AVKit
import AVFoundation


class ViewController: UIViewController {
    var playerVC : PandoraPlayer!
    var array = [AVPlayerItem]()
    var arrayy = [Bundle.main.path(forResource: "1", ofType: "mp3") , Bundle.main.path(forResource: "2", ofType: "mp3")]
 
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
       
    }

    @IBAction func play(_ sender: Any) {
       array = changeToAV(array: arrayy as! [String])
        playerVC = PandoraPlayer.configure(withAVItems: array)
        let transitionDelegate = SPStorkTransitioningDelegate()
        playerVC.transitioningDelegate = transitionDelegate
        playerVC.modalPresentationStyle = .custom
        present(playerVC, animated: true, completion: nil)
        
        
        
    }
    
    func changeToAV(array : [String]) -> [AVPlayerItem] {
        var changedArray = [AVPlayerItem]()
        for i in 0...array.count-1 {
            
            let url = URL(fileURLWithPath: array[i])
            let asset = AVAsset(url: url)
            let item = AVPlayerItem(asset: asset)
            changedArray.append(item)
        }
        return changedArray
    }

    
}

